# Treasure-Hunter

一个用`Godot`游戏引擎制作的2d像素横板游戏,使用的版本是`4.3-stable`

Godot游戏引擎: https://godotengine.org/

美术资源来自: https://pixelfrog-assets.itch.io/treasure-hunters
